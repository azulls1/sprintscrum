# Actividad 1 grupal — Planeación de un sprint en Scrum

**Equipo 2073 F** — Mauricio Alberto Alvarez Aspeitia · Adonai Samael Hernández Mata · Cesar Ivan Martinez Perez · Diego Alfonso Nájera Ortiz
**Asignatura:** Metodología de Diseño y Gestión de Proyectos · Maestría en Inteligencia Artificial (Plan 2024)
**Profesora:** Adriana Cervantes Castillo

## Archivos

| Archivo | Qué es |
|---|---|
| `Actividad1_Grupal_Equipo2073F.docx` | El documento de la actividad (Calibri 12, interlineado 1,5) |
| `Actividad1_Grupal_Equipo2073F.pdf` | El mismo documento en PDF |

## Dónde está cada criterio de la rúbrica

| Criterio | Apartado del documento | En el portal |
|---|---|---|
| 1. Descripción del proyecto | 1. Descripción del proyecto | https://sprintscrum.iagentek.com.mx/proyecto |
| — Asignación de roles | 2. Roles Scrum | https://sprintscrum.iagentek.com.mx/equipo |
| 2. Product backlog | 3. Product backlog (8 historias) | https://sprintscrum.iagentek.com.mx/product-backlog |
| 3. Sprint backlog | 4. Sprint backlog (15 tareas, 51 h) | https://sprintscrum.iagentek.com.mx/sprint-backlog |
| 4. Reflexión individual | 5. Reflexiones (4) | https://sprintscrum.iagentek.com.mx/reflexiones |
| 5. Conclusión grupal | 6. Conclusión | https://sprintscrum.iagentek.com.mx/conclusion |

Portal interactivo con el tablero del sprint, la simulación del sprint y la comprobación de cada requisito:
**https://sprintscrum.iagentek.com.mx** · código: https://github.com/azulls1/sprintscrum
